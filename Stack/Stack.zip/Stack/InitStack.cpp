#include <stdio.h>
#include <stdlib.h>
#include "stack.h"

void InitStack(DoubleStack* S)
{
	S->top = -1;
}

void InitStack(CharStack* S)
{
	S->top = -1;
}